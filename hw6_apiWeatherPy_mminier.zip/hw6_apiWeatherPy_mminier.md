
### Unit 6 | Assignment - What's the Weather Like? 

    Open Weather Map API: https://openweathermap.org/api


```python
from random import *
import random
import json
import requests
import csv
from pprint import pprint
from config import api_key
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from citipy import citipy
import datetime
```


```python
# Establish full range of lon & lat coordinates
lon_samp = np.arange(-180,181,.5)
lat_samp = np.arange(-90,91,.25)

# Create loops that pick 500 random numbers from each list
lon_list1 = sample(set(lon_samp), 720)
lat_list1 = sample(set(lat_samp), 720)
lon_list2 = sample(set(lon_samp), 720)
lat_list2 = sample(set(lat_samp), 720)
lon_list3 = sample(set(lon_samp), 720)
lat_list3 = sample(set(lat_samp), 720)
lon_list4 = sample(set(lon_samp), 720)
lat_list4 = sample(set(lat_samp), 720)
lon_list5 = sample(set(lon_samp), 720)
lat_list5 = sample(set(lat_samp), 720)
lon_list6 = sample(set(lon_samp), 720)
lat_list6 = sample(set(lat_samp), 720)
```


```python
# Create dataframes
citidf1 = pd.DataFrame()
citidf1['lon_est'] = lon_list1
citidf1['lat_est'] = lat_list1

citidf2 = pd.DataFrame()
citidf2['lon_est'] = lon_list2
citidf2['lat_est'] = lat_list2

citidf3 = pd.DataFrame()
citidf3['lon_est'] = lon_list3
citidf3['lat_est'] = lat_list3

citidf4 = pd.DataFrame()
citidf4['lon_est'] = lon_list4
citidf4['lat_est'] = lat_list4

citidf5 = pd.DataFrame()
citidf5['lon_est'] = lon_list5
citidf5['lat_est'] = lat_list5

citidf6 = pd.DataFrame()
citidf6['lon_est'] = lon_list6
citidf6['lat_est'] = lat_list6

# Combine dataframes
citidf = pd.concat([citidf1, citidf2, citidf3, citidf4, citidf5, citidf6])

# Combine lon and lat into coordinates
citidf['coordinates'] = citidf[['lon_est', 'lat_est']].apply(tuple, axis=1)
citidf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>lon_est</th>
      <th>lat_est</th>
      <th>coordinates</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-43.0</td>
      <td>-74.75</td>
      <td>(-43.0, -74.75)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-1.5</td>
      <td>-79.50</td>
      <td>(-1.5, -79.5)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>79.5</td>
      <td>-2.25</td>
      <td>(79.5, -2.25)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>155.5</td>
      <td>-8.00</td>
      <td>(155.5, -8.0)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-29.5</td>
      <td>-48.00</td>
      <td>(-29.5, -48.0)</td>
    </tr>
  </tbody>
</table>
</div>




```python
len(citidf)
```




    4320




```python
# Use citipy to generate a list of cities
cities = []
name = []
country = []

for coordinate_pair in citidf['coordinates']:
    lon, lat = coordinate_pair
    cities.append(citipy.nearest_city(lon, lat))

for city in cities:
    country.append(city.country_code)
    name.append(city.city_name)
    #print(city.city_name)
    #print(f"The country code of {name} is '{country_code}'.")

citidf['city_name'] = name
citidf['country_code'] = country

citidf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>lon_est</th>
      <th>lat_est</th>
      <th>coordinates</th>
      <th>city_name</th>
      <th>country_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-43.0</td>
      <td>-74.75</td>
      <td>(-43.0, -74.75)</td>
      <td>castro</td>
      <td>cl</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-1.5</td>
      <td>-79.50</td>
      <td>(-1.5, -79.5)</td>
      <td>ventanas</td>
      <td>ec</td>
    </tr>
    <tr>
      <th>2</th>
      <td>79.5</td>
      <td>-2.25</td>
      <td>(79.5, -2.25)</td>
      <td>barentsburg</td>
      <td>sj</td>
    </tr>
    <tr>
      <th>3</th>
      <td>155.5</td>
      <td>-8.00</td>
      <td>(155.5, -8.0)</td>
      <td>barentsburg</td>
      <td>sj</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-29.5</td>
      <td>-48.00</td>
      <td>(-29.5, -48.0)</td>
      <td>laguna</td>
      <td>br</td>
    </tr>
  </tbody>
</table>
</div>




```python
len(citidf)
```




    4320




```python
# Drop duplicate cities and print to see if we have at least 500 unique values
citi_df = citidf.drop_duplicates(["city_name"], keep=False)
len(citi_df)
```




    582




```python
# Create a miniDF for testing 
miniDF = citi_df[0:20]
miniDF.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>lon_est</th>
      <th>lat_est</th>
      <th>coordinates</th>
      <th>city_name</th>
      <th>country_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>-1.5</td>
      <td>-79.5</td>
      <td>(-1.5, -79.5)</td>
      <td>ventanas</td>
      <td>ec</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-34.5</td>
      <td>-57.0</td>
      <td>(-34.5, -57.0)</td>
      <td>nueva helvecia</td>
      <td>uy</td>
    </tr>
    <tr>
      <th>8</th>
      <td>14.0</td>
      <td>76.5</td>
      <td>(14.0, 76.5)</td>
      <td>hiriyur</td>
      <td>in</td>
    </tr>
    <tr>
      <th>10</th>
      <td>65.5</td>
      <td>82.0</td>
      <td>(65.5, 82.0)</td>
      <td>krasnoselkup</td>
      <td>ru</td>
    </tr>
    <tr>
      <th>13</th>
      <td>13.0</td>
      <td>36.5</td>
      <td>(13.0, 36.5)</td>
      <td>doka</td>
      <td>sd</td>
    </tr>
  </tbody>
</table>
</div>



#### Sample API response:

    {"coord":{"lon":139,"lat":35},
    "sys":{"country":"JP","sunrise":1369769524,"sunset":1369821049},
    "weather":[{"id":804,"main":"clouds","description":"overcast clouds","icon":"04n"}],
    "main":{"temp":289.5,"humidity":89,"pressure":1013,"temp_min":287.04,"temp_max":292.04},
    "wind":{"speed":7.31,"deg":187.002},
    "rain":{"3h":0},
    "clouds":{"all":92},
    "dt":1369824698,
    "id":1851632,
    "name":"Shuzenji",
    "cod":200}


```python
# Prepare API call
base_url = "https://api.openweathermap.org/data/2.5/weather"
params = {"appid":api_key, "units":"imperial", "type":"like"}
```


```python
# Create dataframe and series to hold final results
df = pd.DataFrame()
df['id'] = ""
df['city'] = ""
df['country'] = ""
df['lon'] = ""
df['lat'] = ""
df['date'] = ""
df['temperature'] = ""
df['humidity'] = ""
df['cloudiness'] = ""
df['wind speed'] = ""
```


```python
# 
city_json = []
city_count = 0

for index, row in citi_df.iterrows():
    city_name = row['city_name']            # search the city_name in each row
    params['q'] = city_name                 # add city_name as keyword to params dictionary (q is per api documentation)

    response = requests.get(base_url, params=params)   # send api request
    print(f"Retrieving information for city #{city_count}: {params['q']}")
    print(response.url)                                # print response url 
    response_json = response.json()                    # convert response to json
    # print(json.dumps(response_json))
 
    try:
        df.at[index,'id'] = response_json['id']
        df.at[index,'city'] = response_json['name']
        df.at[index,'country'] = response_json['sys']['country']
        df.at[index,'lon'] = response_json['coord']['lon']
        df.at[index,'lat'] = response_json['coord']['lat']
        df.at[index,'date'] = response_json['dt']
        df.at[index,'temperature'] = response_json['main']['temp']
        df.at[index,'humidity'] = response_json['main']['humidity']
        df.at[index,'cloudiness'] = response_json['clouds']['all']
        df.at[index,'wind speed'] = response_json['wind']['speed']

        city_count = city_count + 1
        print(f"#{city_count} - {city_name} has been added to df")
    
    except (KeyError, IndexError):
        continue

    if city_count == 500: 
        break
```

    Retrieving information for city #0: ventanas
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ventanas
    #1 - ventanas has been added to df
    Retrieving information for city #1: nueva helvecia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nueva+helvecia
    #2 - nueva helvecia has been added to df
    Retrieving information for city #2: hiriyur
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=hiriyur
    #3 - hiriyur has been added to df
    Retrieving information for city #3: krasnoselkup
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=krasnoselkup
    Retrieving information for city #3: doka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=doka
    #4 - doka has been added to df
    Retrieving information for city #4: pindwara
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pindwara
    #5 - pindwara has been added to df
    Retrieving information for city #5: arys
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=arys
    #6 - arys has been added to df
    Retrieving information for city #6: la palma
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=la+palma
    #7 - la palma has been added to df
    Retrieving information for city #7: ginir
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ginir
    #8 - ginir has been added to df
    Retrieving information for city #8: rio cuarto
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rio+cuarto
    #9 - rio cuarto has been added to df
    Retrieving information for city #9: anori
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=anori
    #10 - anori has been added to df
    Retrieving information for city #10: bolama
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bolama
    #11 - bolama has been added to df
    Retrieving information for city #11: tigre
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tigre
    #12 - tigre has been added to df
    Retrieving information for city #12: ajdabiya
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ajdabiya
    #13 - ajdabiya has been added to df
    Retrieving information for city #13: miquelon
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=miquelon
    #14 - miquelon has been added to df
    Retrieving information for city #14: zaranj
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=zaranj
    #15 - zaranj has been added to df
    Retrieving information for city #15: waddan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=waddan
    #16 - waddan has been added to df
    Retrieving information for city #16: seinajoki
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=seinajoki
    Retrieving information for city #16: salinas
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=salinas
    #17 - salinas has been added to df
    Retrieving information for city #17: nicoya
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nicoya
    #18 - nicoya has been added to df
    Retrieving information for city #18: rognan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rognan
    #19 - rognan has been added to df
    Retrieving information for city #19: palermo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=palermo
    #20 - palermo has been added to df
    Retrieving information for city #20: purpe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=purpe
    #21 - purpe has been added to df
    Retrieving information for city #21: khromtau
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=khromtau
    #22 - khromtau has been added to df
    Retrieving information for city #22: bosaso
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bosaso
    #23 - bosaso has been added to df
    Retrieving information for city #23: crab hill
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=crab+hill
    Retrieving information for city #23: santa maria
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=santa+maria
    #24 - santa maria has been added to df
    Retrieving information for city #24: suluktu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=suluktu
    Retrieving information for city #24: sestri levante
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sestri+levante
    #25 - sestri levante has been added to df
    Retrieving information for city #25: fredericksburg
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=fredericksburg
    #26 - fredericksburg has been added to df
    Retrieving information for city #26: bama
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bama
    #27 - bama has been added to df
    Retrieving information for city #27: caluquembe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=caluquembe
    #28 - caluquembe has been added to df
    Retrieving information for city #28: villamontes
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=villamontes
    #29 - villamontes has been added to df
    Retrieving information for city #29: coracora
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=coracora
    #30 - coracora has been added to df
    Retrieving information for city #30: veinticinco de mayo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=veinticinco+de+mayo
    #31 - veinticinco de mayo has been added to df
    Retrieving information for city #31: ipoti
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ipoti
    #32 - ipoti has been added to df
    Retrieving information for city #32: bayji
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bayji
    #33 - bayji has been added to df
    Retrieving information for city #33: marathon
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=marathon
    #34 - marathon has been added to df
    Retrieving information for city #34: shakawe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=shakawe
    #35 - shakawe has been added to df
    Retrieving information for city #35: diu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=diu
    #36 - diu has been added to df
    Retrieving information for city #36: unai
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=unai
    #37 - unai has been added to df
    Retrieving information for city #37: thinadhoo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=thinadhoo
    #38 - thinadhoo has been added to df
    Retrieving information for city #38: batticaloa
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=batticaloa
    #39 - batticaloa has been added to df
    Retrieving information for city #39: carballo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=carballo
    #40 - carballo has been added to df
    Retrieving information for city #40: salinopolis
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=salinopolis
    #41 - salinopolis has been added to df
    Retrieving information for city #41: bria
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bria
    #42 - bria has been added to df
    Retrieving information for city #42: tatawin
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tatawin
    Retrieving information for city #42: bulawayo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bulawayo
    #43 - bulawayo has been added to df
    Retrieving information for city #43: jardim
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jardim
    #44 - jardim has been added to df
    Retrieving information for city #44: batak
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=batak
    #45 - batak has been added to df
    Retrieving information for city #45: ruwi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ruwi
    #46 - ruwi has been added to df
    Retrieving information for city #46: olinda
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=olinda
    #47 - olinda has been added to df
    Retrieving information for city #47: shahr-e kord
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=shahr-e+kord
    #48 - shahr-e kord has been added to df
    Retrieving information for city #48: bagotville
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bagotville
    #49 - bagotville has been added to df
    Retrieving information for city #49: dakar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dakar
    #50 - dakar has been added to df
    Retrieving information for city #50: gangotri
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gangotri
    Retrieving information for city #50: salym
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=salym
    #51 - salym has been added to df
    Retrieving information for city #51: bargal
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bargal
    Retrieving information for city #51: rancharia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rancharia
    #52 - rancharia has been added to df
    Retrieving information for city #52: kalabo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kalabo
    #53 - kalabo has been added to df
    Retrieving information for city #53: maceio
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=maceio
    #54 - maceio has been added to df
    Retrieving information for city #54: padang
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=padang
    #55 - padang has been added to df
    Retrieving information for city #55: eirunepe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=eirunepe
    #56 - eirunepe has been added to df
    Retrieving information for city #56: boyabat
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=boyabat
    #57 - boyabat has been added to df
    Retrieving information for city #57: bantry
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bantry
    Retrieving information for city #57: zadar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=zadar
    #58 - zadar has been added to df
    Retrieving information for city #58: ermoupolis
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ermoupolis
    #59 - ermoupolis has been added to df
    Retrieving information for city #59: alekseyevka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=alekseyevka
    #60 - alekseyevka has been added to df
    Retrieving information for city #60: aasiaat
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=aasiaat
    #61 - aasiaat has been added to df
    Retrieving information for city #61: san-pedro
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san-pedro
    #62 - san-pedro has been added to df
    Retrieving information for city #62: tenenkou
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tenenkou
    #63 - tenenkou has been added to df
    Retrieving information for city #63: agua caliente de linaca
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=agua+caliente+de+linaca
    Retrieving information for city #63: velyka mykhaylivka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=velyka+mykhaylivka
    #64 - velyka mykhaylivka has been added to df
    Retrieving information for city #64: contamana
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=contamana
    #65 - contamana has been added to df
    Retrieving information for city #65: rio verde de mato grosso
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rio+verde+de+mato+grosso
    #66 - rio verde de mato grosso has been added to df
    Retrieving information for city #66: asmara
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=asmara
    #67 - asmara has been added to df
    Retrieving information for city #67: avrille
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=avrille
    #68 - avrille has been added to df
    Retrieving information for city #68: kharan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kharan
    #69 - kharan has been added to df
    Retrieving information for city #69: pozarevac
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pozarevac
    #70 - pozarevac has been added to df
    Retrieving information for city #70: san carlos
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san+carlos
    #71 - san carlos has been added to df
    Retrieving information for city #71: imbituba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=imbituba
    #72 - imbituba has been added to df
    Retrieving information for city #72: urucara
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=urucara
    #73 - urucara has been added to df
    Retrieving information for city #73: russas
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=russas
    #74 - russas has been added to df
    Retrieving information for city #74: sotouboua
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sotouboua
    #75 - sotouboua has been added to df
    Retrieving information for city #75: cumberland
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cumberland
    #76 - cumberland has been added to df
    Retrieving information for city #76: lafiagi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lafiagi
    #77 - lafiagi has been added to df
    Retrieving information for city #77: colares
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=colares
    #78 - colares has been added to df
    Retrieving information for city #78: constanza
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=constanza
    #79 - constanza has been added to df
    Retrieving information for city #79: antropovo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=antropovo
    #80 - antropovo has been added to df
    Retrieving information for city #80: nisia floresta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nisia+floresta
    #81 - nisia floresta has been added to df
    Retrieving information for city #81: jiwani
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jiwani
    #82 - jiwani has been added to df
    Retrieving information for city #82: waren
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=waren
    Retrieving information for city #82: forio
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=forio
    #83 - forio has been added to df
    Retrieving information for city #83: mogadishu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mogadishu
    #84 - mogadishu has been added to df
    Retrieving information for city #84: bogotol
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bogotol
    #85 - bogotol has been added to df
    Retrieving information for city #85: kilemary
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kilemary
    #86 - kilemary has been added to df
    Retrieving information for city #86: matipo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=matipo
    #87 - matipo has been added to df
    Retrieving information for city #87: wrexham
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=wrexham
    #88 - wrexham has been added to df
    Retrieving information for city #88: uray
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=uray
    #89 - uray has been added to df
    Retrieving information for city #89: peterhead
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=peterhead
    #90 - peterhead has been added to df
    Retrieving information for city #90: sirsa
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sirsa
    #91 - sirsa has been added to df
    Retrieving information for city #91: alexandria
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=alexandria
    #92 - alexandria has been added to df
    Retrieving information for city #92: de aar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=de+aar
    #93 - de aar has been added to df
    Retrieving information for city #93: inverness
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=inverness
    #94 - inverness has been added to df
    Retrieving information for city #94: amapa
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=amapa
    #95 - amapa has been added to df
    Retrieving information for city #95: severnyy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=severnyy
    Retrieving information for city #95: bolungarvik
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bolungarvik
    Retrieving information for city #95: dianopolis
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dianopolis
    Retrieving information for city #95: mercedes
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mercedes
    #96 - mercedes has been added to df
    Retrieving information for city #96: charleston
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=charleston
    #97 - charleston has been added to df
    Retrieving information for city #97: oppdal
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=oppdal
    #98 - oppdal has been added to df
    Retrieving information for city #98: methoni
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=methoni
    #99 - methoni has been added to df
    Retrieving information for city #99: ustye
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ustye
    #100 - ustye has been added to df
    Retrieving information for city #100: bully-les-mines
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bully-les-mines
    #101 - bully-les-mines has been added to df
    Retrieving information for city #101: vanersborg
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=vanersborg
    #102 - vanersborg has been added to df
    Retrieving information for city #102: nikolskoye
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nikolskoye
    #103 - nikolskoye has been added to df
    Retrieving information for city #103: mweka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mweka
    #104 - mweka has been added to df
    Retrieving information for city #104: manaure
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=manaure
    #105 - manaure has been added to df
    Retrieving information for city #105: mortka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mortka
    #106 - mortka has been added to df
    Retrieving information for city #106: biedenkopf
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=biedenkopf
    #107 - biedenkopf has been added to df
    Retrieving information for city #107: tonantins
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tonantins
    #108 - tonantins has been added to df
    Retrieving information for city #108: snezhnogorsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=snezhnogorsk
    #109 - snezhnogorsk has been added to df
    Retrieving information for city #109: robertsport
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=robertsport
    #110 - robertsport has been added to df
    Retrieving information for city #110: challapata
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=challapata
    #111 - challapata has been added to df
    Retrieving information for city #111: kayes
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kayes
    #112 - kayes has been added to df
    Retrieving information for city #112: marica
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=marica
    #113 - marica has been added to df
    Retrieving information for city #113: port-cartier
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=port-cartier
    #114 - port-cartier has been added to df
    Retrieving information for city #114: westerland
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=westerland
    #115 - westerland has been added to df
    Retrieving information for city #115: muisne
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=muisne
    #116 - muisne has been added to df
    Retrieving information for city #116: nuuk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nuuk
    #117 - nuuk has been added to df
    Retrieving information for city #117: quatre cocos
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=quatre+cocos
    #118 - quatre cocos has been added to df
    Retrieving information for city #118: riohacha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=riohacha
    #119 - riohacha has been added to df
    Retrieving information for city #119: port antonio
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=port+antonio
    #120 - port antonio has been added to df
    Retrieving information for city #120: carutapera
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=carutapera
    #121 - carutapera has been added to df
    Retrieving information for city #121: menongue
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=menongue
    #122 - menongue has been added to df
    Retrieving information for city #122: altay
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=altay
    #123 - altay has been added to df
    Retrieving information for city #123: filadelfia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=filadelfia
    #124 - filadelfia has been added to df
    Retrieving information for city #124: suluq
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=suluq
    #125 - suluq has been added to df
    Retrieving information for city #125: acarau
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=acarau
    Retrieving information for city #125: capao bonito
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=capao+bonito
    #126 - capao bonito has been added to df
    Retrieving information for city #126: kempele
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kempele
    #127 - kempele has been added to df
    Retrieving information for city #127: erdemli
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=erdemli
    Retrieving information for city #127: prado
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=prado
    #128 - prado has been added to df
    Retrieving information for city #128: navahrudak
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=navahrudak
    #129 - navahrudak has been added to df
    Retrieving information for city #129: nevsehir
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nevsehir
    #130 - nevsehir has been added to df
    Retrieving information for city #130: asnaes
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=asnaes
    #131 - asnaes has been added to df
    Retrieving information for city #131: izmit
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=izmit
    #132 - izmit has been added to df
    Retrieving information for city #132: oum hadjer
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=oum+hadjer
    #133 - oum hadjer has been added to df
    Retrieving information for city #133: costinesti
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=costinesti
    #134 - costinesti has been added to df
    Retrieving information for city #134: sao domingos
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sao+domingos
    #135 - sao domingos has been added to df
    Retrieving information for city #135: pithiviers
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pithiviers
    #136 - pithiviers has been added to df
    Retrieving information for city #136: aripuana
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=aripuana
    #137 - aripuana has been added to df
    Retrieving information for city #137: puerto ayacucho
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=puerto+ayacucho
    #138 - puerto ayacucho has been added to df
    Retrieving information for city #138: premnitz
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=premnitz
    #139 - premnitz has been added to df
    Retrieving information for city #139: oneonta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=oneonta
    #140 - oneonta has been added to df
    Retrieving information for city #140: sabha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sabha
    #141 - sabha has been added to df
    Retrieving information for city #141: backo gradiste
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=backo+gradiste
    #142 - backo gradiste has been added to df
    Retrieving information for city #142: porto velho
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=porto+velho
    #143 - porto velho has been added to df
    Retrieving information for city #143: iralaya
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=iralaya
    #144 - iralaya has been added to df
    Retrieving information for city #144: kavaratti
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kavaratti
    #145 - kavaratti has been added to df
    Retrieving information for city #145: margate
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=margate
    #146 - margate has been added to df
    Retrieving information for city #146: luebo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=luebo
    #147 - luebo has been added to df
    Retrieving information for city #147: ladario
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ladario
    #148 - ladario has been added to df
    Retrieving information for city #148: kletskaya
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kletskaya
    #149 - kletskaya has been added to df
    Retrieving information for city #149: bara
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bara
    #150 - bara has been added to df
    Retrieving information for city #150: axixa do tocantins
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=axixa+do+tocantins
    Retrieving information for city #150: garowe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=garowe
    #151 - garowe has been added to df
    Retrieving information for city #151: gelemso
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gelemso
    #152 - gelemso has been added to df
    Retrieving information for city #152: mamontovo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mamontovo
    #153 - mamontovo has been added to df
    Retrieving information for city #153: wexford
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=wexford
    #154 - wexford has been added to df
    Retrieving information for city #154: mopipi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mopipi
    #155 - mopipi has been added to df
    Retrieving information for city #155: kargasok
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kargasok
    #156 - kargasok has been added to df
    Retrieving information for city #156: buraydah
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=buraydah
    #157 - buraydah has been added to df
    Retrieving information for city #157: kangaatsiaq
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kangaatsiaq
    #158 - kangaatsiaq has been added to df
    Retrieving information for city #158: tabulbah
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tabulbah
    Retrieving information for city #158: grevena
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=grevena
    #159 - grevena has been added to df
    Retrieving information for city #159: shu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=shu
    #160 - shu has been added to df
    Retrieving information for city #160: viedma
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=viedma
    #161 - viedma has been added to df
    Retrieving information for city #161: attock
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=attock
    #162 - attock has been added to df
    Retrieving information for city #162: oleksandrivka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=oleksandrivka
    #163 - oleksandrivka has been added to df
    Retrieving information for city #163: mochalishche
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mochalishche
    #164 - mochalishche has been added to df
    Retrieving information for city #164: toamasina
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=toamasina
    #165 - toamasina has been added to df
    Retrieving information for city #165: onega
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=onega
    #166 - onega has been added to df
    Retrieving information for city #166: signagi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=signagi
    Retrieving information for city #166: cururupu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cururupu
    #167 - cururupu has been added to df
    Retrieving information for city #167: karpathos
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=karpathos
    #168 - karpathos has been added to df
    Retrieving information for city #168: aswan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=aswan
    #169 - aswan has been added to df
    Retrieving information for city #169: tarko-sale
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tarko-sale
    #170 - tarko-sale has been added to df
    Retrieving information for city #170: viligili
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=viligili
    Retrieving information for city #170: kuusamo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kuusamo
    #171 - kuusamo has been added to df
    Retrieving information for city #171: nantucket
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nantucket
    #172 - nantucket has been added to df
    Retrieving information for city #172: mazagao
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mazagao
    #173 - mazagao has been added to df
    Retrieving information for city #173: urucui
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=urucui
    #174 - urucui has been added to df
    Retrieving information for city #174: khanion tou kokkini
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=khanion+tou+kokkini
    Retrieving information for city #174: spassk-ryazanskiy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=spassk-ryazanskiy
    #175 - spassk-ryazanskiy has been added to df
    Retrieving information for city #175: boende
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=boende
    #176 - boende has been added to df
    Retrieving information for city #176: thouars
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=thouars
    #177 - thouars has been added to df
    Retrieving information for city #177: barbar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=barbar
    Retrieving information for city #177: meaux
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=meaux
    #178 - meaux has been added to df
    Retrieving information for city #178: maldonado
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=maldonado
    #179 - maldonado has been added to df
    Retrieving information for city #179: kedrovyy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kedrovyy
    #180 - kedrovyy has been added to df
    Retrieving information for city #180: ouesso
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ouesso
    #181 - ouesso has been added to df
    Retrieving information for city #181: cockburn harbour
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cockburn+harbour
    Retrieving information for city #181: san
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san
    #182 - san has been added to df
    Retrieving information for city #182: tocopilla
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tocopilla
    #183 - tocopilla has been added to df
    Retrieving information for city #183: truro
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=truro
    #184 - truro has been added to df
    Retrieving information for city #184: dunmore town
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dunmore+town
    #185 - dunmore town has been added to df
    Retrieving information for city #185: achisay
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=achisay
    Retrieving information for city #185: stepnogorsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=stepnogorsk
    #186 - stepnogorsk has been added to df
    Retrieving information for city #186: fria
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=fria
    #187 - fria has been added to df
    Retrieving information for city #187: lubumbashi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lubumbashi
    #188 - lubumbashi has been added to df
    Retrieving information for city #188: kalofer
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kalofer
    #189 - kalofer has been added to df
    Retrieving information for city #189: aqtobe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=aqtobe
    #190 - aqtobe has been added to df
    Retrieving information for city #190: manjacaze
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=manjacaze
    #191 - manjacaze has been added to df
    Retrieving information for city #191: burgeo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=burgeo
    #192 - burgeo has been added to df
    Retrieving information for city #192: plettenberg bay
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=plettenberg+bay
    #193 - plettenberg bay has been added to df
    Retrieving information for city #193: krasnoarmeysk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=krasnoarmeysk
    #194 - krasnoarmeysk has been added to df
    Retrieving information for city #194: pilna
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pilna
    #195 - pilna has been added to df
    Retrieving information for city #195: new richmond
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=new+richmond
    #196 - new richmond has been added to df
    Retrieving information for city #196: dunnville
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dunnville
    #197 - dunnville has been added to df
    Retrieving information for city #197: oparino
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=oparino
    #198 - oparino has been added to df
    Retrieving information for city #198: marau
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=marau
    #199 - marau has been added to df
    Retrieving information for city #199: makokou
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=makokou
    #200 - makokou has been added to df
    Retrieving information for city #200: gaspar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gaspar
    #201 - gaspar has been added to df
    Retrieving information for city #201: inongo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=inongo
    #202 - inongo has been added to df
    Retrieving information for city #202: san julian
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san+julian
    #203 - san julian has been added to df
    Retrieving information for city #203: moba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=moba
    #204 - moba has been added to df
    Retrieving information for city #204: santiago
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=santiago
    #205 - santiago has been added to df
    Retrieving information for city #205: haputale
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=haputale
    #206 - haputale has been added to df
    Retrieving information for city #206: marystown
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=marystown
    #207 - marystown has been added to df
    Retrieving information for city #207: tres arroyos
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tres+arroyos
    #208 - tres arroyos has been added to df
    Retrieving information for city #208: xuddur
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=xuddur
    #209 - xuddur has been added to df
    Retrieving information for city #209: pinega
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pinega
    #210 - pinega has been added to df
    Retrieving information for city #210: chemal
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=chemal
    #211 - chemal has been added to df
    Retrieving information for city #211: klerksdorp
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=klerksdorp
    #212 - klerksdorp has been added to df
    Retrieving information for city #212: luanda
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=luanda
    #213 - luanda has been added to df
    Retrieving information for city #213: mariental
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mariental
    #214 - mariental has been added to df
    Retrieving information for city #214: storebo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=storebo
    #215 - storebo has been added to df
    Retrieving information for city #215: royan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=royan
    #216 - royan has been added to df
    Retrieving information for city #216: curumani
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=curumani
    #217 - curumani has been added to df
    Retrieving information for city #217: lubango
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lubango
    #218 - lubango has been added to df
    Retrieving information for city #218: odweyne
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=odweyne
    Retrieving information for city #218: kasongo-lunda
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kasongo-lunda
    #219 - kasongo-lunda has been added to df
    Retrieving information for city #219: sao felix do xingu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sao+felix+do+xingu
    #220 - sao felix do xingu has been added to df
    Retrieving information for city #220: rajanpur
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rajanpur
    #221 - rajanpur has been added to df
    Retrieving information for city #221: rocha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rocha
    #222 - rocha has been added to df
    Retrieving information for city #222: mastic beach
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mastic+beach
    #223 - mastic beach has been added to df
    Retrieving information for city #223: sarai
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sarai
    #224 - sarai has been added to df
    Retrieving information for city #224: kolyshley
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kolyshley
    #225 - kolyshley has been added to df
    Retrieving information for city #225: hvolsvollur
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=hvolsvollur
    Retrieving information for city #225: dutlwe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dutlwe
    #226 - dutlwe has been added to df
    Retrieving information for city #226: monze
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=monze
    #227 - monze has been added to df
    Retrieving information for city #227: dondo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dondo
    #228 - dondo has been added to df
    Retrieving information for city #228: black river
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=black+river
    #229 - black river has been added to df
    Retrieving information for city #229: rabat
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rabat
    #230 - rabat has been added to df
    Retrieving information for city #230: alappuzha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=alappuzha
    Retrieving information for city #230: san jose
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san+jose
    #231 - san jose has been added to df
    Retrieving information for city #231: bar harbor
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bar+harbor
    #232 - bar harbor has been added to df
    Retrieving information for city #232: kindu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kindu
    #233 - kindu has been added to df
    Retrieving information for city #233: nazilli
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nazilli
    #234 - nazilli has been added to df
    Retrieving information for city #234: marinhas
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=marinhas
    #235 - marinhas has been added to df
    Retrieving information for city #235: valparaiso
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=valparaiso
    #236 - valparaiso has been added to df
    Retrieving information for city #236: benjamin constant
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=benjamin+constant
    #237 - benjamin constant has been added to df
    Retrieving information for city #237: lumeje
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lumeje
    #238 - lumeje has been added to df
    Retrieving information for city #238: ilebo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ilebo
    #239 - ilebo has been added to df
    Retrieving information for city #239: pryozerne
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pryozerne
    #240 - pryozerne has been added to df
    Retrieving information for city #240: usinsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=usinsk
    #241 - usinsk has been added to df
    Retrieving information for city #241: fomboni
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=fomboni
    #242 - fomboni has been added to df
    Retrieving information for city #242: kapiri mposhi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kapiri+mposhi
    #243 - kapiri mposhi has been added to df
    Retrieving information for city #243: cravo norte
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cravo+norte
    #244 - cravo norte has been added to df
    Retrieving information for city #244: ostersund
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ostersund
    #245 - ostersund has been added to df
    Retrieving information for city #245: winneba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=winneba
    #246 - winneba has been added to df
    Retrieving information for city #246: awjilah
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=awjilah
    #247 - awjilah has been added to df
    Retrieving information for city #247: mursalimkino
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mursalimkino
    #248 - mursalimkino has been added to df
    Retrieving information for city #248: araouane
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=araouane
    #249 - araouane has been added to df
    Retrieving information for city #249: provins
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=provins
    #250 - provins has been added to df
    Retrieving information for city #250: yangambi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=yangambi
    #251 - yangambi has been added to df
    Retrieving information for city #251: catamarca
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=catamarca
    Retrieving information for city #251: knysna
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=knysna
    #252 - knysna has been added to df
    Retrieving information for city #252: mahajanga
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mahajanga
    #253 - mahajanga has been added to df
    Retrieving information for city #253: villeta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=villeta
    #254 - villeta has been added to df
    Retrieving information for city #254: ciudad bolivar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ciudad+bolivar
    #255 - ciudad bolivar has been added to df
    Retrieving information for city #255: navoloki
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=navoloki
    #256 - navoloki has been added to df
    Retrieving information for city #256: gazojak
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gazojak
    #257 - gazojak has been added to df
    Retrieving information for city #257: wageningen
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=wageningen
    #258 - wageningen has been added to df
    Retrieving information for city #258: fairhope
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=fairhope
    #259 - fairhope has been added to df
    Retrieving information for city #259: bababe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bababe
    Retrieving information for city #259: rafaela
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rafaela
    #260 - rafaela has been added to df
    Retrieving information for city #260: liwale
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=liwale
    #261 - liwale has been added to df
    Retrieving information for city #261: koson
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=koson
    #262 - koson has been added to df
    Retrieving information for city #262: solsvik
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=solsvik
    Retrieving information for city #262: sovetskiy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sovetskiy
    #263 - sovetskiy has been added to df
    Retrieving information for city #263: maarianhamina
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=maarianhamina
    Retrieving information for city #263: trapani
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=trapani
    #264 - trapani has been added to df
    Retrieving information for city #264: nador
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nador
    #265 - nador has been added to df
    Retrieving information for city #265: verkhnetulomskiy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=verkhnetulomskiy
    #266 - verkhnetulomskiy has been added to df
    Retrieving information for city #266: algiers
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=algiers
    #267 - algiers has been added to df
    Retrieving information for city #267: marabba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=marabba
    #268 - marabba has been added to df
    Retrieving information for city #268: nizhniy odes
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nizhniy+odes
    #269 - nizhniy odes has been added to df
    Retrieving information for city #269: qabis
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=qabis
    Retrieving information for city #269: baghdad
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=baghdad
    #270 - baghdad has been added to df
    Retrieving information for city #270: angoche
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=angoche
    #271 - angoche has been added to df
    Retrieving information for city #271: barawe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=barawe
    Retrieving information for city #271: shetpe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=shetpe
    #272 - shetpe has been added to df
    Retrieving information for city #272: awbari
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=awbari
    #273 - awbari has been added to df
    Retrieving information for city #273: san juan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san+juan
    #274 - san juan has been added to df
    Retrieving information for city #274: kadoma
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kadoma
    #275 - kadoma has been added to df
    Retrieving information for city #275: azimur
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=azimur
    Retrieving information for city #275: martil
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=martil
    #276 - martil has been added to df
    Retrieving information for city #276: yarim
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=yarim
    #277 - yarim has been added to df
    Retrieving information for city #277: berbera
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=berbera
    Retrieving information for city #277: igarka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=igarka
    #278 - igarka has been added to df
    Retrieving information for city #278: bukoba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bukoba
    #279 - bukoba has been added to df
    Retrieving information for city #279: mezen
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mezen
    #280 - mezen has been added to df
    Retrieving information for city #280: bay city
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bay+city
    #281 - bay city has been added to df
    Retrieving information for city #281: guarapari
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=guarapari
    #282 - guarapari has been added to df
    Retrieving information for city #282: ellisras
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ellisras
    #283 - ellisras has been added to df
    Retrieving information for city #283: la baule-escoublac
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=la+baule-escoublac
    #284 - la baule-escoublac has been added to df
    Retrieving information for city #284: inyonga
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=inyonga
    #285 - inyonga has been added to df
    Retrieving information for city #285: aleksandrov gay
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=aleksandrov+gay
    #286 - aleksandrov gay has been added to df
    Retrieving information for city #286: visselhovede
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=visselhovede
    #287 - visselhovede has been added to df
    Retrieving information for city #287: vilhena
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=vilhena
    #288 - vilhena has been added to df
    Retrieving information for city #288: kiruna
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kiruna
    #289 - kiruna has been added to df
    Retrieving information for city #289: galgani
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=galgani
    Retrieving information for city #289: gorom-gorom
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gorom-gorom
    #290 - gorom-gorom has been added to df
    Retrieving information for city #290: igrim
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=igrim
    #291 - igrim has been added to df
    Retrieving information for city #291: amantea
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=amantea
    #292 - amantea has been added to df
    Retrieving information for city #292: pizarro
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pizarro
    #293 - pizarro has been added to df
    Retrieving information for city #293: mecca
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mecca
    #294 - mecca has been added to df
    Retrieving information for city #294: dabat
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dabat
    #295 - dabat has been added to df
    Retrieving information for city #295: panama city
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=panama+city
    #296 - panama city has been added to df
    Retrieving information for city #296: opobo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=opobo
    Retrieving information for city #296: verkhnyaya inta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=verkhnyaya+inta
    #297 - verkhnyaya inta has been added to df
    Retrieving information for city #297: farah
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=farah
    #298 - farah has been added to df
    Retrieving information for city #298: posse
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=posse
    #299 - posse has been added to df
    Retrieving information for city #299: benguela
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=benguela
    #300 - benguela has been added to df
    Retrieving information for city #300: les herbiers
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=les+herbiers
    #301 - les herbiers has been added to df
    Retrieving information for city #301: montorio al vomano
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=montorio+al+vomano
    #302 - montorio al vomano has been added to df
    Retrieving information for city #302: itaituba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=itaituba
    #303 - itaituba has been added to df
    Retrieving information for city #303: tarija
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tarija
    #304 - tarija has been added to df
    Retrieving information for city #304: lunino
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lunino
    #305 - lunino has been added to df
    Retrieving information for city #305: mallaig
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mallaig
    #306 - mallaig has been added to df
    Retrieving information for city #306: nieuw amsterdam
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nieuw+amsterdam
    #307 - nieuw amsterdam has been added to df
    Retrieving information for city #307: arlit
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=arlit
    #308 - arlit has been added to df
    Retrieving information for city #308: bur gabo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bur+gabo
    Retrieving information for city #308: nesterov
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nesterov
    #309 - nesterov has been added to df
    Retrieving information for city #309: silute
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=silute
    #310 - silute has been added to df
    Retrieving information for city #310: upata
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=upata
    #311 - upata has been added to df
    Retrieving information for city #311: machiques
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=machiques
    #312 - machiques has been added to df
    Retrieving information for city #312: tarsus
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tarsus
    #313 - tarsus has been added to df
    Retrieving information for city #313: tubbergen
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tubbergen
    #314 - tubbergen has been added to df
    Retrieving information for city #314: kidal
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kidal
    #315 - kidal has been added to df
    Retrieving information for city #315: tortoli
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tortoli
    #316 - tortoli has been added to df
    Retrieving information for city #316: marsh harbour
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=marsh+harbour
    #317 - marsh harbour has been added to df
    Retrieving information for city #317: turayf
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=turayf
    #318 - turayf has been added to df
    Retrieving information for city #318: nkhotakota
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nkhotakota
    #319 - nkhotakota has been added to df
    Retrieving information for city #319: lgov
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lgov
    Retrieving information for city #319: yeltsovka
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=yeltsovka
    Retrieving information for city #319: mirabad
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mirabad
    #320 - mirabad has been added to df
    Retrieving information for city #320: bogorodskoye
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bogorodskoye
    #321 - bogorodskoye has been added to df
    Retrieving information for city #321: esna
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=esna
    #322 - esna has been added to df
    Retrieving information for city #322: belogorsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=belogorsk
    #323 - belogorsk has been added to df
    Retrieving information for city #323: pangoa
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pangoa
    #324 - pangoa has been added to df
    Retrieving information for city #324: mocambique
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mocambique
    Retrieving information for city #324: san ignacio
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san+ignacio
    #325 - san ignacio has been added to df
    Retrieving information for city #325: arauca
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=arauca
    #326 - arauca has been added to df
    Retrieving information for city #326: nouakchott
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nouakchott
    #327 - nouakchott has been added to df
    Retrieving information for city #327: spisska nova ves
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=spisska+nova+ves
    #328 - spisska nova ves has been added to df
    Retrieving information for city #328: bonthe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bonthe
    #329 - bonthe has been added to df
    Retrieving information for city #329: willowmore
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=willowmore
    #330 - willowmore has been added to df
    Retrieving information for city #330: gambela
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gambela
    #331 - gambela has been added to df
    Retrieving information for city #331: pitimbu
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pitimbu
    #332 - pitimbu has been added to df
    Retrieving information for city #332: lawrenceburg
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lawrenceburg
    #333 - lawrenceburg has been added to df
    Retrieving information for city #333: clarksburg
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=clarksburg
    #334 - clarksburg has been added to df
    Retrieving information for city #334: teguldet
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=teguldet
    #335 - teguldet has been added to df
    Retrieving information for city #335: tuggurt
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tuggurt
    Retrieving information for city #335: tazovskiy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tazovskiy
    #336 - tazovskiy has been added to df
    Retrieving information for city #336: meybod
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=meybod
    #337 - meybod has been added to df
    Retrieving information for city #337: sao gabriel
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sao+gabriel
    #338 - sao gabriel has been added to df
    Retrieving information for city #338: meulaboh
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=meulaboh
    #339 - meulaboh has been added to df
    Retrieving information for city #339: treinta y tres
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=treinta+y+tres
    #340 - treinta y tres has been added to df
    Retrieving information for city #340: johnson city
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=johnson+city
    #341 - johnson city has been added to df
    Retrieving information for city #341: santa lucia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=santa+lucia
    #342 - santa lucia has been added to df
    Retrieving information for city #342: ati
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ati
    #343 - ati has been added to df
    Retrieving information for city #343: labutta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=labutta
    Retrieving information for city #343: paramonga
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=paramonga
    #344 - paramonga has been added to df
    Retrieving information for city #344: corner brook
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=corner+brook
    #345 - corner brook has been added to df
    Retrieving information for city #345: jagatsinghapur
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jagatsinghapur
    #346 - jagatsinghapur has been added to df
    Retrieving information for city #346: taltal
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=taltal
    #347 - taltal has been added to df
    Retrieving information for city #347: penha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=penha
    #348 - penha has been added to df
    Retrieving information for city #348: mandiana
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mandiana
    #349 - mandiana has been added to df
    Retrieving information for city #349: nortelandia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nortelandia
    #350 - nortelandia has been added to df
    Retrieving information for city #350: poros
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=poros
    #351 - poros has been added to df
    Retrieving information for city #351: kerchevskiy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kerchevskiy
    #352 - kerchevskiy has been added to df
    Retrieving information for city #352: gilazi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gilazi
    Retrieving information for city #352: kalmunai
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kalmunai
    #353 - kalmunai has been added to df
    Retrieving information for city #353: paso de carrasco
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=paso+de+carrasco
    #354 - paso de carrasco has been added to df
    Retrieving information for city #354: miandrivazo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=miandrivazo
    #355 - miandrivazo has been added to df
    Retrieving information for city #355: kudahuvadhoo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kudahuvadhoo
    #356 - kudahuvadhoo has been added to df
    Retrieving information for city #356: llandrindod wells
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=llandrindod+wells
    #357 - llandrindod wells has been added to df
    Retrieving information for city #357: tafresh
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tafresh
    #358 - tafresh has been added to df
    Retrieving information for city #358: atbasar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=atbasar
    #359 - atbasar has been added to df
    Retrieving information for city #359: cabedelo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cabedelo
    #360 - cabedelo has been added to df
    Retrieving information for city #360: vigrestad
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=vigrestad
    #361 - vigrestad has been added to df
    Retrieving information for city #361: teguise
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=teguise
    #362 - teguise has been added to df
    Retrieving information for city #362: abadiania
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=abadiania
    #363 - abadiania has been added to df
    Retrieving information for city #363: buchanan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=buchanan
    #364 - buchanan has been added to df
    Retrieving information for city #364: kazalinsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kazalinsk
    Retrieving information for city #364: macenta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=macenta
    #365 - macenta has been added to df
    Retrieving information for city #365: bella union
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bella+union
    #366 - bella union has been added to df
    Retrieving information for city #366: eufaula
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=eufaula
    #367 - eufaula has been added to df
    Retrieving information for city #367: urdzhar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=urdzhar
    Retrieving information for city #367: viru
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=viru
    #368 - viru has been added to df
    Retrieving information for city #368: yarmouth
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=yarmouth
    #369 - yarmouth has been added to df
    Retrieving information for city #369: fereydun kenar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=fereydun+kenar
    #370 - fereydun kenar has been added to df
    Retrieving information for city #370: nefteyugansk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nefteyugansk
    #371 - nefteyugansk has been added to df
    Retrieving information for city #371: jurbise
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jurbise
    #372 - jurbise has been added to df
    Retrieving information for city #372: graaff-reinet
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=graaff-reinet
    #373 - graaff-reinet has been added to df
    Retrieving information for city #373: kharovsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kharovsk
    #374 - kharovsk has been added to df
    Retrieving information for city #374: jamame
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jamame
    #375 - jamame has been added to df
    Retrieving information for city #375: jega
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jega
    #376 - jega has been added to df
    Retrieving information for city #376: qasigiannguit
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=qasigiannguit
    #377 - qasigiannguit has been added to df
    Retrieving information for city #377: viransehir
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=viransehir
    #378 - viransehir has been added to df
    Retrieving information for city #378: tabou
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tabou
    #379 - tabou has been added to df
    Retrieving information for city #379: kardymovo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kardymovo
    #380 - kardymovo has been added to df
    Retrieving information for city #380: eyl
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=eyl
    #381 - eyl has been added to df
    Retrieving information for city #381: trinidad
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=trinidad
    #382 - trinidad has been added to df
    Retrieving information for city #382: talcahuano
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=talcahuano
    #383 - talcahuano has been added to df
    Retrieving information for city #383: jacareacanga
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jacareacanga
    #384 - jacareacanga has been added to df
    Retrieving information for city #384: kuryk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kuryk
    #385 - kuryk has been added to df
    Retrieving information for city #385: urfa
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=urfa
    Retrieving information for city #385: ankara
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ankara
    #386 - ankara has been added to df
    Retrieving information for city #386: peniche
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=peniche
    #387 - peniche has been added to df
    Retrieving information for city #387: manta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=manta
    #388 - manta has been added to df
    Retrieving information for city #388: novosokolniki
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=novosokolniki
    #389 - novosokolniki has been added to df
    Retrieving information for city #389: morondava
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=morondava
    #390 - morondava has been added to df
    Retrieving information for city #390: harnosand
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=harnosand
    #391 - harnosand has been added to df
    Retrieving information for city #391: tingrela
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tingrela
    Retrieving information for city #391: itabira
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=itabira
    #392 - itabira has been added to df
    Retrieving information for city #392: umm lajj
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=umm+lajj
    #393 - umm lajj has been added to df
    Retrieving information for city #393: mao
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mao
    #394 - mao has been added to df
    Retrieving information for city #394: abha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=abha
    #395 - abha has been added to df
    Retrieving information for city #395: osorno
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=osorno
    #396 - osorno has been added to df
    Retrieving information for city #396: kristiinankaupunki
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kristiinankaupunki
    Retrieving information for city #396: dzialdowo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dzialdowo
    #397 - dzialdowo has been added to df
    Retrieving information for city #397: svecha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=svecha
    #398 - svecha has been added to df
    Retrieving information for city #398: jammal
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=jammal
    #399 - jammal has been added to df
    Retrieving information for city #399: gwadar
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gwadar
    #400 - gwadar has been added to df
    Retrieving information for city #400: lubao
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lubao
    #401 - lubao has been added to df
    Retrieving information for city #401: pilikwe
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pilikwe
    #402 - pilikwe has been added to df
    Retrieving information for city #402: chavakachcheri
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=chavakachcheri
    #403 - chavakachcheri has been added to df
    Retrieving information for city #403: venado tuerto
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=venado+tuerto
    #404 - venado tuerto has been added to df
    Retrieving information for city #404: romodanovo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=romodanovo
    #405 - romodanovo has been added to df
    Retrieving information for city #405: mettur
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mettur
    #406 - mettur has been added to df
    Retrieving information for city #406: aranos
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=aranos
    #407 - aranos has been added to df
    Retrieving information for city #407: chone
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=chone
    #408 - chone has been added to df
    Retrieving information for city #408: karaman
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=karaman
    Retrieving information for city #408: artyom
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=artyom
    #409 - artyom has been added to df
    Retrieving information for city #409: staden
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=staden
    #410 - staden has been added to df
    Retrieving information for city #410: road town
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=road+town
    #411 - road town has been added to df
    Retrieving information for city #411: bayir
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bayir
    #412 - bayir has been added to df
    Retrieving information for city #412: arkhangelsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=arkhangelsk
    #413 - arkhangelsk has been added to df
    Retrieving information for city #413: goundam
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=goundam
    #414 - goundam has been added to df
    Retrieving information for city #414: brae
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=brae
    #415 - brae has been added to df
    Retrieving information for city #415: mbini
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mbini
    #416 - mbini has been added to df
    Retrieving information for city #416: santa cecilia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=santa+cecilia
    #417 - santa cecilia has been added to df
    Retrieving information for city #417: bay roberts
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bay+roberts
    #418 - bay roberts has been added to df
    Retrieving information for city #418: antofagasta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=antofagasta
    #419 - antofagasta has been added to df
    Retrieving information for city #419: ferrol
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ferrol
    #420 - ferrol has been added to df
    Retrieving information for city #420: lipin bor
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lipin+bor
    #421 - lipin bor has been added to df
    Retrieving information for city #421: toma
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=toma
    #422 - toma has been added to df
    Retrieving information for city #422: rosetta
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=rosetta
    #423 - rosetta has been added to df
    Retrieving information for city #423: banepa
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=banepa
    #424 - banepa has been added to df
    Retrieving information for city #424: campamento
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=campamento
    #425 - campamento has been added to df
    Retrieving information for city #425: mizan teferi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mizan+teferi
    #426 - mizan teferi has been added to df
    Retrieving information for city #426: xapuri
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=xapuri
    #427 - xapuri has been added to df
    Retrieving information for city #427: general roca
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=general+roca
    #428 - general roca has been added to df
    Retrieving information for city #428: kashi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kashi
    Retrieving information for city #428: grabovo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=grabovo
    #429 - grabovo has been added to df
    Retrieving information for city #429: tiznit
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tiznit
    #430 - tiznit has been added to df
    Retrieving information for city #430: panaba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=panaba
    #431 - panaba has been added to df
    Retrieving information for city #431: makhachkala
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=makhachkala
    #432 - makhachkala has been added to df
    Retrieving information for city #432: dingli
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dingli
    #433 - dingli has been added to df
    Retrieving information for city #433: estelle
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=estelle
    #434 - estelle has been added to df
    Retrieving information for city #434: svetlyy
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=svetlyy
    Retrieving information for city #434: playas
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=playas
    #435 - playas has been added to df
    Retrieving information for city #435: skjaerhollen
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=skjaerhollen
    Retrieving information for city #435: pyshchug
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=pyshchug
    #436 - pyshchug has been added to df
    Retrieving information for city #436: subaytilah
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=subaytilah
    Retrieving information for city #436: lagos
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lagos
    #437 - lagos has been added to df
    Retrieving information for city #437: ilo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ilo
    #438 - ilo has been added to df
    Retrieving information for city #438: nokaneng
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=nokaneng
    #439 - nokaneng has been added to df
    Retrieving information for city #439: solano
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=solano
    #440 - solano has been added to df
    Retrieving information for city #440: kongolo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kongolo
    #441 - kongolo has been added to df
    Retrieving information for city #441: barra do garcas
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=barra+do+garcas
    #442 - barra do garcas has been added to df
    Retrieving information for city #442: waw
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=waw
    Retrieving information for city #442: sao benedito do rio preto
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sao+benedito+do+rio+preto
    #443 - sao benedito do rio preto has been added to df
    Retrieving information for city #443: segezha
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=segezha
    #444 - segezha has been added to df
    Retrieving information for city #444: heinola
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=heinola
    #445 - heinola has been added to df
    Retrieving information for city #445: owando
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=owando
    #446 - owando has been added to df
    Retrieving information for city #446: tartagal
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tartagal
    #447 - tartagal has been added to df
    Retrieving information for city #447: ozark
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ozark
    #448 - ozark has been added to df
    Retrieving information for city #448: karakol
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=karakol
    #449 - karakol has been added to df
    Retrieving information for city #449: zhezkazgan
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=zhezkazgan
    #450 - zhezkazgan has been added to df
    Retrieving information for city #450: soyo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=soyo
    #451 - soyo has been added to df
    Retrieving information for city #451: lebowakgomo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=lebowakgomo
    #452 - lebowakgomo has been added to df
    Retrieving information for city #452: torres
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=torres
    #453 - torres has been added to df
    Retrieving information for city #453: shache
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=shache
    #454 - shache has been added to df
    Retrieving information for city #454: provaton
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=provaton
    Retrieving information for city #454: abeche
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=abeche
    #455 - abeche has been added to df
    Retrieving information for city #455: bagua grande
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bagua+grande
    #456 - bagua grande has been added to df
    Retrieving information for city #456: kasane
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kasane
    #457 - kasane has been added to df
    Retrieving information for city #457: karauzyak
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=karauzyak
    Retrieving information for city #457: malia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=malia
    #458 - malia has been added to df
    Retrieving information for city #458: kolondieba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kolondieba
    #459 - kolondieba has been added to df
    Retrieving information for city #459: totness
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=totness
    #460 - totness has been added to df
    Retrieving information for city #460: hami
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=hami
    #461 - hami has been added to df
    Retrieving information for city #461: tsienyane
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tsienyane
    Retrieving information for city #461: copiapo
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=copiapo
    #462 - copiapo has been added to df
    Retrieving information for city #462: gao
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=gao
    #463 - gao has been added to df
    Retrieving information for city #463: brufut
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=brufut
    #464 - brufut has been added to df
    Retrieving information for city #464: cordoba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cordoba
    #465 - cordoba has been added to df
    Retrieving information for city #465: burica
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=burica
    Retrieving information for city #465: kulhudhuffushi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=kulhudhuffushi
    #466 - kulhudhuffushi has been added to df
    Retrieving information for city #466: santa isabel do rio negro
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=santa+isabel+do+rio+negro
    #467 - santa isabel do rio negro has been added to df
    Retrieving information for city #467: presidencia roque saenz pena
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=presidencia+roque+saenz+pena
    #468 - presidencia roque saenz pena has been added to df
    Retrieving information for city #468: villa maria
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=villa+maria
    #469 - villa maria has been added to df
    Retrieving information for city #469: fort-de-france
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=fort-de-france
    #470 - fort-de-france has been added to df
    Retrieving information for city #470: samana
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=samana
    #471 - samana has been added to df
    Retrieving information for city #471: moyale
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=moyale
    #472 - moyale has been added to df
    Retrieving information for city #472: priverno
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=priverno
    #473 - priverno has been added to df
    Retrieving information for city #473: muana
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=muana
    #474 - muana has been added to df
    Retrieving information for city #474: duisburg
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=duisburg
    #475 - duisburg has been added to df
    Retrieving information for city #475: bombay
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bombay
    #476 - bombay has been added to df
    Retrieving information for city #476: bom jardim
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=bom+jardim
    #477 - bom jardim has been added to df
    Retrieving information for city #477: little current
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=little+current
    #478 - little current has been added to df
    Retrieving information for city #478: mayumba
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=mayumba
    #479 - mayumba has been added to df
    Retrieving information for city #479: tselinnoye
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=tselinnoye
    #480 - tselinnoye has been added to df
    Retrieving information for city #480: abalak
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=abalak
    #481 - abalak has been added to df
    Retrieving information for city #481: sumbawanga
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sumbawanga
    #482 - sumbawanga has been added to df
    Retrieving information for city #482: izazi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=izazi
    #483 - izazi has been added to df
    Retrieving information for city #483: umm kaddadah
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=umm+kaddadah
    #484 - umm kaddadah has been added to df
    Retrieving information for city #484: wa
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=wa
    Retrieving information for city #484: saint charles
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=saint+charles
    #485 - saint charles has been added to df
    Retrieving information for city #485: sunam
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=sunam
    #486 - sunam has been added to df
    Retrieving information for city #486: solvychegodsk
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=solvychegodsk
    #487 - solvychegodsk has been added to df
    Retrieving information for city #487: domoni
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=domoni
    Retrieving information for city #487: asfi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=asfi
    Retrieving information for city #487: roding
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=roding
    #488 - roding has been added to df
    Retrieving information for city #488: cartagena
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cartagena
    #489 - cartagena has been added to df
    Retrieving information for city #489: ornskoldsvik
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=ornskoldsvik
    #490 - ornskoldsvik has been added to df
    Retrieving information for city #490: trairi
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=trairi
    #491 - trairi has been added to df
    Retrieving information for city #491: port shepstone
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=port+shepstone
    #492 - port shepstone has been added to df
    Retrieving information for city #492: alfonsine
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=alfonsine
    #493 - alfonsine has been added to df
    Retrieving information for city #493: san miguel
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=san+miguel
    #494 - san miguel has been added to df
    Retrieving information for city #494: higuey
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=higuey
    Retrieving information for city #494: apollonia
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=apollonia
    #495 - apollonia has been added to df
    Retrieving information for city #495: calama
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=calama
    #496 - calama has been added to df
    Retrieving information for city #496: candolim
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=candolim
    #497 - candolim has been added to df
    Retrieving information for city #497: cherepovets
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=cherepovets
    #498 - cherepovets has been added to df
    Retrieving information for city #498: dharchula
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=dharchula
    #499 - dharchula has been added to df
    Retrieving information for city #499: metkovic
    https://api.openweathermap.org/data/2.5/weather?appid=f60742b2784a10349f691adcfe4c61a2&units=imperial&type=like&q=metkovic
    #500 - metkovic has been added to df
    


```python
# Convert unix timestamps to datetime
for row in df['date']:
    df['date'] = datetime.datetime.utcfromtimestamp(row)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>city</th>
      <th>country</th>
      <th>lon</th>
      <th>lat</th>
      <th>date</th>
      <th>temperature</th>
      <th>humidity</th>
      <th>cloudiness</th>
      <th>wind speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>3868621</td>
      <td>Ventanas</td>
      <td>CL</td>
      <td>-71.48</td>
      <td>-32.74</td>
      <td>2018-04-03 17:00:00</td>
      <td>66.13</td>
      <td>68</td>
      <td>0</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2332459</td>
      <td>Lagos</td>
      <td>NG</td>
      <td>3.39</td>
      <td>6.46</td>
      <td>2018-04-03 17:00:00</td>
      <td>85.07</td>
      <td>73</td>
      <td>0</td>
      <td>10.87</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1270032</td>
      <td>Hiriyur</td>
      <td>IN</td>
      <td>76.62</td>
      <td>13.94</td>
      <td>2018-04-03 17:00:00</td>
      <td>67.34</td>
      <td>91</td>
      <td>0</td>
      <td>5.39</td>
    </tr>
    <tr>
      <th>13</th>
      <td>376332</td>
      <td>Doka</td>
      <td>SD</td>
      <td>35.76</td>
      <td>13.52</td>
      <td>2018-04-03 17:00:00</td>
      <td>80.84</td>
      <td>28</td>
      <td>0</td>
      <td>7.52</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1259638</td>
      <td>Pindwara</td>
      <td>IN</td>
      <td>73.05</td>
      <td>24.79</td>
      <td>2018-04-03 17:00:00</td>
      <td>67.61</td>
      <td>49</td>
      <td>0</td>
      <td>3.6</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Export dataframe to CSV
df.to_csv("weatherPy2.csv")
```

### WeatherPy Plots

* Temperature (F) vs. Latitude
* Humidity (%) vs. Latitude
* Cloudiness (%) vs. Latitude
* Wind Speed (mph) vs. Latitude


```python
def pproperties(x_label, y_label, x_lim):
    plt.title(f"{y_label} vs {x_label}")
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.xlim(x_lim)
    plt.grid(True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>city</th>
      <th>country</th>
      <th>lon</th>
      <th>lat</th>
      <th>date</th>
      <th>temperature</th>
      <th>humidity</th>
      <th>cloudiness</th>
      <th>wind speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>3868621</td>
      <td>Ventanas</td>
      <td>CL</td>
      <td>-71.48</td>
      <td>-32.74</td>
      <td>2018-04-03 17:00:00</td>
      <td>66.13</td>
      <td>68</td>
      <td>0</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2332459</td>
      <td>Lagos</td>
      <td>NG</td>
      <td>3.39</td>
      <td>6.46</td>
      <td>2018-04-03 17:00:00</td>
      <td>85.07</td>
      <td>73</td>
      <td>0</td>
      <td>10.87</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1270032</td>
      <td>Hiriyur</td>
      <td>IN</td>
      <td>76.62</td>
      <td>13.94</td>
      <td>2018-04-03 17:00:00</td>
      <td>67.34</td>
      <td>91</td>
      <td>0</td>
      <td>5.39</td>
    </tr>
    <tr>
      <th>13</th>
      <td>376332</td>
      <td>Doka</td>
      <td>SD</td>
      <td>35.76</td>
      <td>13.52</td>
      <td>2018-04-03 17:00:00</td>
      <td>80.84</td>
      <td>28</td>
      <td>0</td>
      <td>7.52</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1259638</td>
      <td>Pindwara</td>
      <td>IN</td>
      <td>73.05</td>
      <td>24.79</td>
      <td>2018-04-03 17:00:00</td>
      <td>67.61</td>
      <td>49</td>
      <td>0</td>
      <td>3.6</td>
    </tr>
  </tbody>
</table>
</div>




```python
# increase plot size
plt.rcParams["figure.figsize"]=[10,6]

#ax = plt.axes()
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set(ylim=(-90,90),
      xlabel='Temperature (F)',
      ylabel='Latitude',
      title='Temperature (F) vs. Latitude');

plt.axhline(0, color='red', alpha=0.5)
plt.scatter(df['temperature'], df['lat'], alpha=0.5, c=df['temperature'], cmap='magma')
plt.colorbar()
plt.savefig('1_temp.png')

```


![png](output_19_0.png)



```python
# increase plot size
plt.rcParams["figure.figsize"]=[10,6]

#ax = plt.axes()
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set(xlim=(-90,90),
      xlabel='Latitude',
      ylabel='Humidity',
      title='Humidity vs. Latitude');

plt.axvline(0, color='red', alpha=0.5)
plt.scatter(df['lat'], df['humidity'], alpha=0.5, c=df['humidity'], cmap='magma')
plt.colorbar()
plt.savefig('2-humidity.png')
```


![png](output_20_0.png)



```python
# increase plot size
plt.rcParams["figure.figsize"]=[10,6]

#ax = plt.axes()
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set(xlim=(-90,90),
      xlabel='Latitude',
      ylabel='Cloudiness',
      title='Cloudiness vs. Latitude');

plt.axvline(0, color='red', alpha=0.5)
plt.scatter(df['lat'], df['cloudiness'], alpha=0.5, c=df['cloudiness'], cmap='magma')
plt.colorbar()
plt.savefig('3_cloudiness.png')
```


![png](output_21_0.png)



```python
# increase plot size
plt.rcParams["figure.figsize"]=[10,6]

#ax = plt.axes()
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set(xlim=(-90,90),
      xlabel='Latitude',
      ylabel='Wind Speed (mph)',
      title='Wind Speed (mph) vs. Latitude');

plt.axvline(0, color='red', alpha=0.5)
plt.scatter(df['lat'], df['wind speed'], alpha=0.5, c=df['wind speed'], cmap='magma')
plt.colorbar()
plt.savefig('4_wind.png')
```


![png](output_22_0.png)



```python
# increase plot size
plt.rcParams["figure.figsize"]=[14,8]

#ax = plt.axes()
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set(ylim=(-90,90),
       xlim=(-180,180),
      xlabel='Longitude',
      ylabel='Latitude',
      title='World Temperatures - April 3, 2018');

plt.axhline(0, color='red', alpha=0.5)
plt.scatter(df['lon'], df['lat'], alpha=0.5, c=df['temperature'], cmap='magma')
plt.colorbar()
plt.savefig('5_world.png')
```


![png](output_23_0.png)


**Observations:**
* There is a clear correlation between temperature and latitude. You can see that temperatures increase as you approach the equator.
* Based on the limited data available, it appears that it was wind speeds were higher in the cities towards the north on this day in April.
* There's no clear correlation between latitude and cloudiness/humidity based on this small subset of data on this one particular day, however, humidity would be higher in tropically-situated cities near water.
